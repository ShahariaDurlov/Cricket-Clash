/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useCallback } from 'react';
import { GameStats, GameDifficulty } from './types';
import { DIFFICULTY_CONFIG } from './constants';
import { sounds } from './audio';
import { CricketGame } from './components/CricketGame';
import { ScoreOverlay } from './components/ScoreOverlay';
import { StartModal, ResultModal, HowToPlayModal } from './components/Modals';

export default function App() {
  const [difficulty, setDifficulty] = useState<GameDifficulty>('pro');
  const [isMuted, setIsMuted] = useState<boolean>(sounds.getIsMuted());
  const [copiedToast, setCopiedToast] = useState<boolean>(false);

  // Generate initial stats with dynamic, varied targets so each match is a unique challenge!
  const createInitialStats = useCallback((diff: GameDifficulty): GameStats => {
    const cfg = DIFFICULTY_CONFIG[diff];
    // Dynamic random target variance:
    // Rookie: 12 - 16 runs
    // Pro: 16 - 22 runs
    // Legend: 22 - 28 runs
    let minTarget = 16;
    let maxTarget = 22;
    if (diff === 'rookie') {
      minTarget = 12;
      maxTarget = 16;
    } else if (diff === 'legend') {
      minTarget = 22;
      maxTarget = 28;
    }
    const variedTarget = Math.floor(Math.random() * (maxTarget - minTarget + 1)) + minTarget;

    return {
      totalRuns: 0,
      targetRuns: variedTarget,
      ballsBowled: 0,
      totalBalls: cfg.balls,
      wicketsLost: 0,
      maxWickets: cfg.wickets,
      foursCount: 0,
      sixesCount: 0,
      highestShotSpeed: 0,
      history: [],
    };
  }, []);

  const [stats, setStats] = useState<GameStats>(() => createInitialStats('pro'));
  const [gameKey, setGameKey] = useState<number>(1);
  const [isStartOpen, setIsStartOpen] = useState<boolean>(false);
  const [isResultOpen, setIsResultOpen] = useState<boolean>(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState<boolean>(false);
  const [hasWon, setHasWon] = useState<boolean>(false);

  // Toggle Mute
  const handleToggleMute = useCallback(() => {
    const next = !isMuted;
    setIsMuted(next);
    sounds.setMuted(next);
  }, [isMuted]);

  // Start new match
  const handleStartMatch = useCallback((chosenDiff: GameDifficulty) => {
    setDifficulty(chosenDiff);
    setStats(createInitialStats(chosenDiff));
    setIsStartOpen(false);
    setIsResultOpen(false);
    setGameKey(k => k + 1);
  }, [createInitialStats]);

  // Restart match with fresh varied target
  const handleRestartMatch = useCallback(() => {
    setStats(createInitialStats(difficulty));
    setIsResultOpen(false);
    setGameKey(k => k + 1);
  }, [createInitialStats, difficulty]);

  // Game over event
  const handleGameOver = useCallback((won: boolean) => {
    setHasWon(won);
    setIsResultOpen(true);
  }, []);

  // Share Game link handler
  const handleShareGame = useCallback(() => {
    const currentUrl = window.location.href;
    const shareUrl = currentUrl.includes('ais-dev') || currentUrl.includes('ais-pre')
      ? currentUrl
      : 'https://ais-pre-suuvx5hd4kvpaxts265htt-8257138612.asia-southeast1.run.app';

    const shareData = {
      title: 'Cricket Clash: Super Over',
      text: `Can you chase down ${stats.targetRuns} runs in 6 balls? Play Cricket Clash now! 🏏⚡`,
      url: shareUrl,
    };

    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      navigator.share(shareData).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareUrl).then(() => {
        setCopiedToast(true);
        setTimeout(() => setCopiedToast(false), 2600);
      }).catch(() => {
        // Fallback prompt if clipboard access blocked
        window.prompt('Copy game link to share:', shareUrl);
      });
    }
  }, [stats.targetRuns]);

  return (
    <div className="fixed inset-0 w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden font-sans select-none touch-none">
      {/* Stadium Ambient Glow in background */}
      <div className="absolute inset-0 pointer-events-none opacity-30 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-emerald-900/60 via-slate-950 to-slate-950" />

      {/* Mobile App Canvas Shell */}
      <div className="relative w-full h-full max-w-[450px] flex flex-col justify-between bg-slate-950 shadow-2xl overflow-hidden border-x border-slate-900/50">
        {/* Top Score HUD */}
        <ScoreOverlay stats={stats} />

        {/* Cricket Field Canvas Arena */}
        <div className="flex-1 w-full relative overflow-hidden">
          <CricketGame
            key={gameKey}
            difficulty={difficulty}
            stats={stats}
            onStatsUpdate={setStats}
            onGameOver={handleGameOver}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onShowHowToPlay={() => setIsHowToPlayOpen(true)}
            onRestartMatch={handleRestartMatch}
            onShareGame={handleShareGame}
          />
        </div>
      </div>

      {/* Copied to clipboard Toast Notification */}
      {copiedToast && (
        <div className="fixed top-14 z-50 px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-full shadow-2xl border border-emerald-400 flex items-center gap-2 animate-bounce">
          <span>✅</span>
          <span>Game link copied to clipboard!</span>
        </div>
      )}

      {/* Game Modals */}
      <StartModal
        isOpen={isStartOpen}
        onStart={handleStartMatch}
        selectedDifficulty={difficulty}
        onSelectDifficulty={setDifficulty}
      />

      <ResultModal
        isOpen={isResultOpen}
        won={hasWon}
        stats={stats}
        difficulty={difficulty}
        onReplay={handleRestartMatch}
        onChangeDifficulty={() => {
          setIsResultOpen(false);
          setIsStartOpen(true);
        }}
        onShare={handleShareGame}
      />

      <HowToPlayModal
        isOpen={isHowToPlayOpen}
        onClose={() => setIsHowToPlayOpen(false)}
      />
    </div>
  );
}
