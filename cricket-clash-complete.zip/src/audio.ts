/**
 * High-performance Web Audio API Sound Synthesizer for Cricket Clash.
 * Generates all realistic arcade cricket sound effects procedurally.
 * Zero external audio files required — 100% offline and instant loading.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Check saved audio preference
    try {
      const saved = localStorage.getItem('cricket_audio_muted');
      if (saved !== null) {
        this.isMuted = saved === 'true';
      }
    } catch {
      this.isMuted = false;
    }
  }

  private initContext(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    try {
      localStorage.setItem('cricket_audio_muted', muted ? 'true' : 'false');
    } catch {}
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Crisp Bat Hit sound (resonant English Willow wood strike)
   */
  public playBatHit(quality: 'perfect' | 'good' | 'early_late' = 'good') {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const t = ctx.currentTime;

    // 1. High-frequency crack noise burst
    const bufferSize = ctx.sampleRate * (quality === 'perfect' ? 0.045 : 0.035);
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const noiseFilter = ctx.createBiquadFilter();
    noiseFilter.type = 'bandpass';
    noiseFilter.frequency.setValueAtTime(quality === 'perfect' ? 2400 : 1800, t);
    noiseFilter.Q.setValueAtTime(3.0, t);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(quality === 'perfect' ? 1.0 : 0.7, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

    whiteNoise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(ctx.destination);

    whiteNoise.start(t);

    // 2. Resonant wood body tone (thump/pop of bat)
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';

    const baseFreq = quality === 'perfect' ? 780 : 640;
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(140, t + 0.09);

    oscGain.gain.setValueAtTime(quality === 'perfect' ? 0.9 : 0.6, t);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);

    osc.connect(oscGain);
    oscGain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.1);

    // 3. For perfect hit, add extra power 'boom' punch
    if (quality === 'perfect') {
      const punchOsc = ctx.createOscillator();
      const punchGain = ctx.createGain();
      punchOsc.type = 'sine';
      punchOsc.frequency.setValueAtTime(180, t);
      punchOsc.frequency.exponentialRampToValueAtTime(45, t + 0.14);

      punchGain.gain.setValueAtTime(0.7, t);
      punchGain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);

      punchOsc.connect(punchGain);
      punchGain.connect(ctx.destination);
      punchOsc.start(t);
      punchOsc.stop(t + 0.15);
    }
  }

  /**
   * Stumps crash & wooden bails flying (Bowled / Run Out)
   */
  public playWicket() {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const t = ctx.currentTime;

    // Multiple staggered wood clicks
    for (let i = 0; i < 3; i++) {
      const clickTime = t + i * 0.035;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'square';
      osc.frequency.setValueAtTime(1200 - i * 250, clickTime);
      osc.frequency.exponentialRampToValueAtTime(200, clickTime + 0.04);

      gain.gain.setValueAtTime(0.4, clickTime);
      gain.gain.exponentialRampToValueAtTime(0.001, clickTime + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(clickTime);
      osc.stop(clickTime + 0.05);
    }

    // Low hollow impact
    const thud = ctx.createOscillator();
    const thudGain = ctx.createGain();
    thud.type = 'triangle';
    thud.frequency.setValueAtTime(320, t);
    thud.frequency.exponentialRampToValueAtTime(60, t + 0.2);

    thudGain.gain.setValueAtTime(0.8, t);
    thudGain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

    thud.connect(thudGain);
    thudGain.connect(ctx.destination);
    thud.start(t);
    thud.stop(t + 0.25);
  }

  /**
   * Pitch bounce thud
   */
  public playBounce() {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(65, t + 0.06);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.06);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.07);
  }

  /**
   * Whoosh of ball release / air cut
   */
  public playWhoosh() {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const bufferSize = ctx.sampleRate * 0.12;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(400, t);
    filter.frequency.linearRampToValueAtTime(1400, t + 0.06);
    filter.frequency.exponentialRampToValueAtTime(250, t + 0.12);
    filter.Q.setValueAtTime(2, t);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.05, t);
    gain.gain.linearRampToValueAtTime(0.3, t + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    noise.start(t);
  }

  /**
   * Crowd cheering roar (for 4s, 6s and victory)
   */
  public playCheer(type: 'four' | 'six' | 'victory') {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const duration = type === 'six' ? 1.8 : type === 'victory' ? 2.5 : 1.2;
    const t = ctx.currentTime;
    const bufferSize = ctx.sampleRate * duration;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * 0.7;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;

    // Modulated bandpass filter gives the crowd "roar" texture
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(600, t);
    filter.frequency.linearRampToValueAtTime(1100, t + 0.3);
    filter.frequency.exponentialRampToValueAtTime(450, t + duration);
    filter.Q.setValueAtTime(1.5, t);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.02, t);
    gain.gain.linearRampToValueAtTime(type === 'six' ? 0.45 : 0.35, t + 0.25);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    noise.start(t);

    // For Six or Victory: add celebratory synth fanfare horns
    if (type === 'six' || type === 'victory') {
      const notes = type === 'six' ? [523.25, 659.25, 783.99, 1046.5] : [440, 554.37, 659.25, 880, 1108.7];
      notes.forEach((freq, idx) => {
        const noteTime = t + idx * 0.12;
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, noteTime);

        noteGain.gain.setValueAtTime(0.15, noteTime);
        noteGain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.28);

        osc.connect(noteGain);
        noteGain.connect(ctx.destination);

        osc.start(noteTime);
        osc.stop(noteTime + 0.3);
      });
    }
  }

  /**
   * UI Click / Tap
   */
  public playClick() {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(400, t + 0.03);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.04);
  }

  /**
   * Miss / Dot ball whistle
   */
  public playMiss() {
    if (this.isMuted) return;
    const ctx = this.initContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(320, t);
    osc.frequency.linearRampToValueAtTime(210, t + 0.15);

    gain.gain.setValueAtTime(0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    osc.stop(t + 0.17);
  }
}

export const sounds = new SoundEngine();
