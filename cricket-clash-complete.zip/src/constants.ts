import { BallDelivery, GameDifficulty } from './types';

// Virtual Coordinate System (Optimized for Mobile Portrait 9:16)
export const VIRTUAL_WIDTH = 450;
export const VIRTUAL_HEIGHT = 800;

export const PITCH_CONFIG = {
  width: 96,
  topY: 165,
  bottomY: 710,
  bowlerY: 140,
  bowlerCreaseY: 180,
  batsmanCreaseY: 690,
  stumpsY: 715,
  topStumpsY: 175,
  strikeZoneMinY: 650,
  strikeZoneMaxY: 725,
  perfectStrikeY: 685,
};

export const DIFFICULTY_CONFIG: Record<GameDifficulty, { target: number; balls: number; wickets: number; label: string; speedMultiplier: number }> = {
  rookie: {
    target: 14,
    balls: 6,
    wickets: 2,
    label: 'Rookie (14 Runs)',
    speedMultiplier: 0.88,
  },
  pro: {
    target: 18,
    balls: 6,
    wickets: 2,
    label: 'Pro Super Over (18 Runs)',
    speedMultiplier: 1.0,
  },
  legend: {
    target: 24,
    balls: 6,
    wickets: 2,
    label: 'Legend (24 Runs)',
    speedMultiplier: 1.15,
  },
};

export const DELIVERIES: BallDelivery[] = [
  {
    type: 'fast',
    name: 'Thunder Fast',
    speedKmh: 148,
    color: '#ef4444', // Red marker
    targetX: 225,
    bounceY: 480,
    curveX: 0,
    description: 'Straight bullet delivery right on the stumps! Fast reaction required.',
  },
  {
    type: 'cutter',
    name: 'Off Cutter',
    speedKmh: 118,
    color: '#06b6d4', // Cyan marker
    targetX: 245,
    bounceY: 510,
    curveX: -32,
    description: 'Slows down and breaks sharply off the pitch! Wait for it.',
  },
  {
    type: 'inswinger',
    name: 'In-Swinger',
    speedKmh: 138,
    color: '#f59e0b', // Amber/Yellow
    targetX: 255,
    bounceY: 470,
    curveX: -45,
    description: 'Drifts in the air towards your pads! Watch the line.',
  },
  {
    type: 'outswinger',
    name: 'Out-Swinger',
    speedKmh: 142,
    color: '#a855f7', // Purple
    targetX: 200,
    bounceY: 465,
    curveX: 42,
    description: 'Bends away outside off-stump! Great for a cover drive.',
  },
  {
    type: 'yorker',
    name: 'Toe-Crushing Yorker',
    speedKmh: 145,
    color: '#ec4899', // Pink
    targetX: 225,
    bounceY: 640,
    curveX: 0,
    description: 'Pitches right in the blockhole at your toes! Dig it out quickly.',
  },
];

export const COMMENTARY_LINES = {
  six: [
    'SIX!! That has flown into the upper tier of the pavilion!',
    'MAXIMUM! Dispatched like an absolute bullet over the boundary!',
    'BOOM! Clean contact! That is gone all the way into orbit!',
    'MASSIVE HIT! Picked the bones out of that delivery!',
    'SWEET SOUND OF WILLOW! 6 runs straight down the ground!',
  ],
  four: [
    'FOUR! Pierced the infield gap with surgical precision!',
    'CRACKING SHOT! Races across the lightning-fast outfield!',
    'FOUR RUNS! Exquisite timing, the deep fielders had no chance!',
    'BEAUTIFULLY PLAYED! Skimming over the turf to the fence!',
    'WHAT A TIMING! Finds the rope effortlessly!',
  ],
  runs_3: [
    'Brilliant running between the wickets! They sprint back for three!',
    'Fielder stops it right on the boundary edge, batters take three!',
  ],
  runs_2: [
    'Pushed into the gap, swift calling and they get two comfortably!',
    'Steered into deep mid-wicket for a sharp couple of runs!',
  ],
  runs_1: [
    'Tucked off the pads for a quick single to keep the strike!',
    'Dabbed into the covers, rotates the strike with one run.',
  ],
  dot: [
    'Swing and a miss! Beaten by the movement outside the off stump!',
    'Dot ball! Superb bowling under immense Super Over pressure!',
    'Straight to the fielder inside the circle! No run taken.',
  ],
  bowled: [
    'BOWLED HIM!! The timber goes flying! Stumps shattered!',
    'CLEAN BOWLED! What a ripper! Off-stump knocked out of the ground!',
    'HE MISSES, BOWLER HITS! Catastrophic wicket in the Super Over!',
  ],
  caught: [
    'CAUGHT! Taken safely in the deep! What a clutch catch under the lights!',
    'OUT! Skied it high into the night sky and swallowed by the fielder!',
    'GONE! Magnificent diving catch right at the boundary cushion!',
  ],
  lbw: [
    'APPEAL AND GIVEN! Trapped plumb in front! Umpire raises the finger!',
    'LBW! Struck on the pads right in line with the stumps!',
  ],
};
