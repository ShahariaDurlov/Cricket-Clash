import React from 'react';
import { GameStats } from '../types';

interface ScoreOverlayProps {
  stats: GameStats;
}

export const ScoreOverlay: React.FC<ScoreOverlayProps> = ({ stats }) => {
  const runsNeeded = Math.max(0, stats.targetRuns - stats.totalRuns);
  const ballsLeft = Math.max(0, stats.totalBalls - stats.ballsBowled);
  const wicketsLeft = Math.max(0, stats.maxWickets - stats.wicketsLost);

  // Compute Required Run Rate (RRR)
  const rrr = ballsLeft > 0 ? ((runsNeeded / ballsLeft) * 6).toFixed(1) : '0.0';

  // Last ball commentary
  const lastHistory = stats.history[stats.history.length - 1];
  const commentaryText = lastHistory ? lastHistory.commentary : 'Super Over has begun! Chase down the target to win!';

  return (
    <div className="w-full max-w-[450px] mx-auto px-3 pt-2 pb-1 bg-slate-900/95 border-b border-slate-800 text-slate-100 shadow-md">
      {/* Primary Score Row */}
      <div className="flex items-center justify-between gap-2">
        {/* Runs & Wickets */}
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl font-black tracking-tight text-white">
            {stats.totalRuns}
            <span className="text-slate-400 text-lg font-bold">/{stats.wicketsLost}</span>
          </span>
          <span className="text-xs text-slate-400 font-medium">
            ({Math.floor(stats.ballsBowled / 6)}.{stats.ballsBowled % 6} ov)
          </span>
        </div>

        {/* Center: Target & Equation */}
        <div className="flex flex-col items-center">
          <div className="text-[11px] font-bold text-amber-400 tracking-wide uppercase">
            {runsNeeded === 0 
              ? 'Target Achieved!' 
              : `Need ${runsNeeded} off ${ballsLeft} ball${ballsLeft === 1 ? '' : 's'}`}
          </div>
          <div className="text-[10px] text-slate-400">
            Target: <span className="text-slate-200 font-semibold">{stats.targetRuns}</span> · RRR: <span className="text-slate-200 font-semibold">{rrr}</span>
          </div>
        </div>

        {/* Wickets in hand indicator */}
        <div className="flex items-center gap-1">
          <span className="text-[11px] text-slate-400">Wkts:</span>
          <span className="text-sm font-bold text-emerald-400">{wicketsLeft}</span>
        </div>
      </div>

      {/* Ball by Ball Tracker Over Strip */}
      <div className="mt-1.5 flex items-center justify-between gap-1.5">
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          {Array.from({ length: stats.totalBalls }).map((_, idx) => {
            const entry = stats.history[idx];
            if (!entry) {
              return (
                <div
                  key={idx}
                  className="w-6 h-6 rounded-md bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-[10px] text-slate-500 font-bold"
                >
                  •
                </div>
              );
            }

            let bgClass = 'bg-slate-700 text-slate-200';
            if (entry.isWicket) {
              bgClass = 'bg-red-600 text-white font-black shadow-sm shadow-red-900/50';
            } else if (entry.runs === 6) {
              bgClass = 'bg-amber-500 text-slate-950 font-black shadow-sm shadow-amber-900/50';
            } else if (entry.runs === 4) {
              bgClass = 'bg-emerald-600 text-white font-black shadow-sm shadow-emerald-900/50';
            } else if (entry.runs > 0) {
              bgClass = 'bg-sky-600 text-white font-bold';
            } else {
              bgClass = 'bg-slate-800 text-slate-400 font-medium';
            }

            return (
              <div
                key={idx}
                className={`w-6 h-6 rounded-md flex items-center justify-center text-[11px] transition-transform ${bgClass}`}
                title={entry.commentary}
              >
                {entry.isWicket ? 'W' : entry.runs === 0 ? '0' : entry.runs}
              </div>
            );
          })}
        </div>

        {/* Boundary counts */}
        <div className="flex items-center gap-2 text-[10px] text-slate-400 shrink-0">
          <span>4s: <strong className="text-emerald-400">{stats.foursCount}</strong></span>
          <span>6s: <strong className="text-amber-400">{stats.sixesCount}</strong></span>
        </div>
      </div>

      {/* Live Commentary Ticker */}
      <div className="mt-1 px-2 py-0.5 rounded bg-slate-950/60 text-[11px] text-slate-300 truncate border border-slate-800/50">
        🎙️ {commentaryText}
      </div>
    </div>
  );
};
