import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  VIRTUAL_WIDTH, 
  VIRTUAL_HEIGHT, 
  PITCH_CONFIG, 
  DELIVERIES, 
  COMMENTARY_LINES,
  DIFFICULTY_CONFIG
} from '../constants';
import { 
  GameStats, 
  GamePhase, 
  BallDelivery, 
  Fielder, 
  Particle, 
  BallTrail, 
  FloatingText, 
  ShotOutcome, 
  GameDifficulty 
} from '../types';
import { sounds } from '../audio';

interface CricketGameProps {
  difficulty: GameDifficulty;
  stats: GameStats;
  onStatsUpdate: (newStats: GameStats) => void;
  onGameOver: (won: boolean) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onShowHowToPlay: () => void;
  onRestartMatch: () => void;
  onShareGame: () => void;
}

export const CricketGame: React.FC<CricketGameProps> = ({
  difficulty,
  stats,
  onStatsUpdate,
  onGameOver,
  isMuted,
  onToggleMute,
  onShowHowToPlay,
  onRestartMatch,
  onShareGame,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game internal state references to avoid stale closures in RAF loop
  const phaseRef = useRef<GamePhase>('idle');
  const currentDeliveryRef = useRef<BallDelivery>(DELIVERIES[0]);
  const statsRef = useRef<GameStats>(stats);
  statsRef.current = stats;

  // Ball physics
  const ballRef = useRef({
    x: 225,
    y: PITCH_CONFIG.bowlerY,
    z: 0, // Height in air
    vx: 0,
    vy: 0,
    vz: 0,
    gravity: 0.35,
    bounced: false, // Pitch bounce before reaching bat
    hitBouncedOnOutfield: false, // Has the struck ball touched the turf?
    isLofted: false, // Was the shot played in the air?
    shotPower: 0,
    radius: 6,
    speedMultiplier: 1.0,
    inAirTrajectory: false,
    shotHit: false,
    isOut: false,
    outType: '' as 'bowled' | 'caught' | 'lbw' | '',
  });

  // Shot mode: 'ground' for surgical 4s through the gaps, 'loft' for soaring 6s
  const [shotMode, setShotMode] = useState<'ground' | 'loft'>('ground');
  const shotModeRef = useRef<'ground' | 'loft'>('ground');
  shotModeRef.current = shotMode;

  // Batsman animation state
  const batsmanRef = useRef({
    x: 225,
    y: PITCH_CONFIG.batsmanCreaseY + 12,
    stance: 'ready', // 'ready' | 'swing_left' | 'swing_straight' | 'swing_right' | 'bowled'
    swingProgress: 0,
    targetAngle: 0,
  });

  // Bowler animation state
  const bowlerRef = useRef({
    x: 225,
    y: PITCH_CONFIG.bowlerY,
    armAngle: 0,
    isRunning: false,
    runupOffset: 0,
  });

  // Stumps state
  const stumpsRef = useRef({
    bowled: false,
    bails: [
      { x: 222, y: PITCH_CONFIG.stumpsY - 22, vx: 0, vy: 0, rot: 0, vRot: 0 },
      { x: 228, y: PITCH_CONFIG.stumpsY - 22, vx: 0, vy: 0, rot: 0, vRot: 0 },
    ],
  });

  // Fielders (4 outfielders)
  const fieldersRef = useRef<Fielder[]>([
    {
      id: 1,
      name: 'Deep Mid-Wicket',
      x: 75,
      y: 420,
      targetX: 75,
      targetY: 420,
      speed: 3.2,
      radius: 14,
      isDiving: false,
      diveProgress: 0,
      color: '#38bdf8',
      zone: 'midwicket',
    },
    {
      id: 2,
      name: 'Long-On',
      x: 160,
      y: 260,
      targetX: 160,
      targetY: 260,
      speed: 3.4,
      radius: 14,
      isDiving: false,
      diveProgress: 0,
      color: '#38bdf8',
      zone: 'longon',
    },
    {
      id: 3,
      name: 'Long-Off / Cover',
      x: 290,
      y: 260,
      targetX: 290,
      targetY: 260,
      speed: 3.4,
      radius: 14,
      isDiving: false,
      diveProgress: 0,
      color: '#38bdf8',
      zone: 'cover',
    },
    {
      id: 4,
      name: 'Deep Point / Sweeper',
      x: 375,
      y: 420,
      targetX: 375,
      targetY: 420,
      speed: 3.2,
      radius: 14,
      isDiving: false,
      diveProgress: 0,
      color: '#38bdf8',
      zone: 'point',
    },
  ]);

  // Visual effects
  const particlesRef = useRef<Particle[]>([]);
  const ballTrailsRef = useRef<BallTrail[]>([]);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const screenShakeRef = useRef({ x: 0, y: 0, intensity: 0 });
  const speedLinesRef = useRef<{ active: boolean; opacity: number }>({ active: false, opacity: 0 });
  const crowdWaveRef = useRef(0);

  // Swipe & input tracking
  const touchStartPos = useRef<{ x: number; y: number; time: number } | null>(null);
  const touchCurrentPos = useRef<{ x: number; y: number } | null>(null);

  // Next delivery countdown / ready state
  const [phase, setPhase] = useState<GamePhase>('idle');
  const [currentDelivery, setCurrentDelivery] = useState<BallDelivery>(DELIVERIES[0]);
  const [canSwing, setCanSwing] = useState(false);
  const [lastShotFeedback, setLastShotFeedback] = useState<string>('');

  // Spawn visual floating text
  const addFloatingText = useCallback((text: string, x: number, y: number, color = '#facc15', subtext?: string) => {
    floatingTextsRef.current.push({
      id: Math.random(),
      text,
      subtext,
      x,
      y,
      vy: -1.8,
      scale: 1.4,
      color,
      alpha: 1.0,
      life: 0,
    });
  }, []);

  // Spawn particle explosions (confetti, dust, sparks)
  const spawnParticles = useCallback((
    x: number, 
    y: number, 
    count: number, 
    colors: string[], 
    type: 'confetti' | 'sparks' | 'dust' = 'sparks'
  ) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = type === 'confetti' ? 2 + Math.random() * 6 : 1.5 + Math.random() * 4.5;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - (type === 'confetti' ? 2 : 0),
        size: type === 'confetti' ? 5 + Math.random() * 5 : 2 + Math.random() * 3.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        life: 0,
        maxLife: type === 'confetti' ? 80 + Math.random() * 40 : 35 + Math.random() * 25,
        shape: type === 'confetti' ? (Math.random() > 0.5 ? 'rect' : 'circle') : 'circle',
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 0.2,
      });
    }
  }, []);

  // Trigger screen shake
  const triggerScreenShake = useCallback((intensity = 8) => {
    screenShakeRef.current.intensity = intensity;
  }, []);

  // Prepare the next delivery (without auto-starting runup until player is ready)
  const setupDelivery = useCallback((autoStart = false) => {
    const diff = DIFFICULTY_CONFIG[difficulty];
    const availableDeliveries = DELIVERIES;
    const nextDelivery = availableDeliveries[Math.floor(Math.random() * availableDeliveries.length)];
    currentDeliveryRef.current = nextDelivery;
    setCurrentDelivery(nextDelivery);

    // Reset ball
    ballRef.current = {
      x: 225,
      y: PITCH_CONFIG.bowlerY,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      gravity: 0.35,
      bounced: false,
      hitBouncedOnOutfield: false,
      isLofted: false,
      shotPower: 0,
      radius: 6,
      speedMultiplier: diff.speedMultiplier,
      inAirTrajectory: false,
      shotHit: false,
      isOut: false,
      outType: '',
    };

    // Reset batsman stance
    batsmanRef.current = {
      x: 225,
      y: PITCH_CONFIG.batsmanCreaseY + 12,
      stance: 'ready',
      swingProgress: 0,
      targetAngle: 0,
    };

    // Reset bowler
    bowlerRef.current = {
      x: 225,
      y: PITCH_CONFIG.bowlerY,
      armAngle: 0,
      isRunning: false,
      runupOffset: -25,
    };

    // Reset fielders to home positions
    const defaultPositions = [
      { x: 80, y: 440 },
      { x: 165, y: 260 },
      { x: 285, y: 260 },
      { x: 370, y: 440 },
    ];
    fieldersRef.current.forEach((f, idx) => {
      f.targetX = defaultPositions[idx].x;
      f.targetY = defaultPositions[idx].y;
      f.isDiving = false;
      f.diveProgress = 0;
    });

    stumpsRef.current.bowled = false;
    stumpsRef.current.bails = [
      { x: 222, y: PITCH_CONFIG.stumpsY - 22, vx: 0, vy: 0, rot: 0, vRot: 0 },
      { x: 228, y: PITCH_CONFIG.stumpsY - 22, vx: 0, vy: 0, rot: 0, vRot: 0 },
    ];

    ballTrailsRef.current = [];
    speedLinesRef.current = { active: false, opacity: 0 };

    if (autoStart) {
      bowlerRef.current.isRunning = true;
      phaseRef.current = 'bowler_runup';
      setPhase('bowler_runup');
      setCanSwing(false);
      setTimeout(() => {
        sounds.playWhoosh();
      }, 450);
    } else {
      phaseRef.current = 'ready_to_bowl';
      setPhase('ready_to_bowl');
      setCanSwing(false);
    }
  }, [difficulty]);

  // Player triggers bowling delivery
  const startBowling = useCallback(() => {
    if (phaseRef.current !== 'ready_to_bowl') return;
    bowlerRef.current.isRunning = true;
    phaseRef.current = 'bowler_runup';
    setPhase('bowler_runup');
    setCanSwing(false);

    sounds.playClick();
    setTimeout(() => {
      sounds.playWhoosh();
    }, 450);
  }, []);

  // Check end of match condition or prepare next delivery
  const handleBallOutcome = useCallback((outcome: ShotOutcome, runs: number) => {
    phaseRef.current = 'ball_dead';
    setPhase('ball_dead');
    setCanSwing(false);

    const isWkt = outcome === 'bowled' || outcome === 'caught' || outcome === 'lbw';
    const comments = COMMENTARY_LINES[outcome];
    const comment = comments[Math.floor(Math.random() * comments.length)];

    const updatedBalls = statsRef.current.ballsBowled + 1;
    const updatedRuns = statsRef.current.totalRuns + runs;
    const updatedWickets = statsRef.current.wicketsLost + (isWkt ? 1 : 0);
    const updatedFours = statsRef.current.foursCount + (outcome === 'four' ? 1 : 0);
    const updatedSixes = statsRef.current.sixesCount + (outcome === 'six' ? 1 : 0);
    const speed = currentDeliveryRef.current.speedKmh;
    const bestSpeed = Math.max(statsRef.current.highestShotSpeed, runs >= 4 ? speed + Math.floor(Math.random() * 12) : 0);

    const newHistoryEntry = {
      ballNumber: updatedBalls,
      outcome,
      runs,
      isWicket: isWkt,
      commentary: comment,
      speedKmh: speed,
      shotType: isWkt ? 'Wicket' : `${runs} Runs`,
    };

    const newStats: GameStats = {
      ...statsRef.current,
      totalRuns: updatedRuns,
      ballsBowled: updatedBalls,
      wicketsLost: updatedWickets,
      foursCount: updatedFours,
      sixesCount: updatedSixes,
      highestShotSpeed: bestSpeed,
      history: [...statsRef.current.history, newHistoryEntry],
    };

    statsRef.current = newStats;
    onStatsUpdate(newStats);

    // Check game termination (Victory or Defeat)
    const won = updatedRuns >= newStats.targetRuns;
    const lost = updatedWickets >= newStats.maxWickets || (updatedBalls >= newStats.totalBalls && !won);

    if (won) {
      setTimeout(() => {
        sounds.playCheer('victory');
        spawnParticles(225, 400, 100, ['#22c55e', '#3b82f6', '#facc15', '#ec4899', '#ffffff'], 'confetti');
        phaseRef.current = 'victory';
        setPhase('victory');
        onGameOver(true);
      }, 1200);
    } else if (lost) {
      setTimeout(() => {
        phaseRef.current = 'game_over';
        setPhase('game_over');
        onGameOver(false);
      }, 1400);
    } else {
      // Next ball after 1.4 seconds
      setTimeout(() => {
        setupDelivery(false);
      }, 1400);
    }
  }, [onStatsUpdate, onGameOver, spawnParticles, setupDelivery]);

  // Batting swing executor (with realistic ground drives for FOURS and lofted hits for SIXES)
  const executeSwing = useCallback((direction: 'left' | 'straight' | 'right', isLoftOverride?: boolean) => {
    if (phaseRef.current !== 'ball_in_air_to_batsman') return;
    if (ballRef.current.shotHit) return;

    const ball = ballRef.current;
    const distanceToCrease = ball.y - PITCH_CONFIG.perfectStrikeY;
    const absDist = Math.abs(distanceToCrease);

    // Calculate timing quality
    let quality: 'perfect' | 'good' | 'early' | 'late' | 'miss' = 'miss';
    if (absDist <= 22) {
      quality = 'perfect';
    } else if (absDist <= 50) {
      quality = distanceToCrease < 0 ? 'early' : 'good';
    } else if (absDist <= 85) {
      quality = distanceToCrease < 0 ? 'early' : 'late';
    } else {
      quality = 'miss';
    }

    // Set batsman swing animation
    batsmanRef.current.stance = direction === 'left' ? 'swing_left' : direction === 'straight' ? 'swing_straight' : 'swing_right';
    batsmanRef.current.swingProgress = 1.0;

    if (quality === 'miss') {
      sounds.playMiss();
      setLastShotFeedback('MISSED!');
      addFloatingText('MISSED!', 225, PITCH_CONFIG.batsmanCreaseY - 30, '#94a3b8');
      return;
    }

    // Contact made with bat!
    ball.shotHit = true;
    phaseRef.current = 'ball_struck';
    setPhase('ball_struck');

    const isPerfect = quality === 'perfect';
    sounds.playBatHit(isPerfect ? 'perfect' : quality === 'good' ? 'good' : 'early_late');

    // Determine loft mode:
    const isLofted = isLoftOverride !== undefined ? isLoftOverride : shotModeRef.current === 'loft';
    ball.isLofted = isLofted;
    ball.hitBouncedOnOutfield = false;

    // Directional angles
    // Left: pull/leg glance through mid-wicket / fine leg
    // Straight: straight drive down the ground
    // Right: cover drive / cut into off-side gaps
    let shotAngle = -Math.PI / 2;
    if (direction === 'left') {
      shotAngle = -Math.PI * 0.74 + (Math.random() - 0.5) * 0.18;
    } else if (direction === 'right') {
      shotAngle = -Math.PI * 0.26 + (Math.random() - 0.5) * 0.18;
    } else {
      shotAngle = -Math.PI * 0.50 + (Math.random() - 0.5) * 0.12;
    }

    // Realistic Power & Elevation Calculation
    let power = 12.0;
    let initialVz = 0.2;

    if (!isLofted) {
      // 🎯 GROUND SHOT: Stays along the turf! Cannot be caught in the air!
      // Races through gaps between fielders to score authentic FOURS!
      initialVz = 0.3; // Stays on grass
      if (isPerfect) {
        power = 15.2; // Piercing ground drive! Races to boundary rope for FOUR!
      } else if (quality === 'good') {
        power = 12.8; // Strong drive into gap
      } else {
        power = 8.5;  // Soft push for 1 or 2 runs
      }
    } else {
      // 🚀 LOFTED SHOT: High aerial hit!
      // Perfect timing = Clears boundary on the full for a SIX!
      // Good timing = Lands in outfield and bounces over rope for a FOUR!
      // Mistimed (Early/Late) = Skies into the air, high risk of being CAUGHT OUT!
      if (isPerfect) {
        power = 16.5;
        initialVz = 11.5; // Clears the fence on the full for a SIX!
      } else if (quality === 'good') {
        power = 13.0;
        initialVz = 8.2;  // Bounces in outfield then rolls over boundary for a FOUR!
      } else {
        power = 6.8;
        initialVz = 9.5;  // Skies high in the air without distance (Catchable!)
      }
    }

    // Extra pace bonus from delivery speed
    power += (currentDeliveryRef.current.speedKmh - 110) * 0.04;
    ball.shotPower = power;

    ball.vx = Math.cos(shotAngle) * power;
    ball.vy = Math.sin(shotAngle) * power;
    ball.vz = initialVz;
    ball.z = isLofted ? 2.5 : 0;
    ball.inAirTrajectory = isLofted;

    // Visual feedback
    triggerScreenShake(isPerfect ? (isLofted ? 14 : 9) : 6);
    const feedbackText = isPerfect ? 'PERFECT TIMING!' : quality === 'good' ? 'GOOD TIMING' : quality.toUpperCase();
    const feedbackColor = isPerfect ? '#22c55e' : quality === 'good' ? '#38bdf8' : '#f59e0b';
    setLastShotFeedback(feedbackText);
    addFloatingText(feedbackText, 225, PITCH_CONFIG.batsmanCreaseY - 45, feedbackColor, isLofted ? '🚀 Aerial Hit' : '🎯 Ground Stroke');

    // Sparks off bat
    spawnParticles(ball.x, ball.y, isPerfect ? 24 : 12, ['#facc15', '#ffffff', '#fb923c'], 'sparks');

    // Activate speed lines on huge 6 hit
    if (isPerfect && isLofted) {
      speedLinesRef.current = { active: true, opacity: 1.0 };
    }

    // Direct outfield fielders to intercept predicted landing
    const predictedX = Math.max(40, Math.min(410, ball.x + ball.vx * 26));
    const predictedY = Math.max(120, Math.min(600, ball.y + ball.vy * 26));

    // Find closest fielder
    let closestFielder = fieldersRef.current[0];
    let minDist = 9999;
    fieldersRef.current.forEach(f => {
      const d = Math.hypot(f.x - predictedX, f.y - predictedY);
      if (d < minDist) {
        minDist = d;
        closestFielder = f;
      }
    });

    closestFielder.targetX = predictedX;
    closestFielder.targetY = predictedY;

  }, [addFloatingText, triggerScreenShake, spawnParticles]);

  // Initialize and handle Start match
  useEffect(() => {
    setupDelivery();
  }, [setupDelivery]);

  // Main Canvas Render & Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      // Dynamic crowd cheering wave
      crowdWaveRef.current += 0.05;

      // Handle screen shake decay
      if (screenShakeRef.current.intensity > 0) {
        screenShakeRef.current.x = (Math.random() - 0.5) * screenShakeRef.current.intensity;
        screenShakeRef.current.y = (Math.random() - 0.5) * screenShakeRef.current.intensity;
        screenShakeRef.current.intensity *= 0.88;
        if (screenShakeRef.current.intensity < 0.2) {
          screenShakeRef.current.intensity = 0;
          screenShakeRef.current.x = 0;
          screenShakeRef.current.y = 0;
        }
      }

      ctx.save();
      ctx.translate(screenShakeRef.current.x, screenShakeRef.current.y);

      // ----------------------------------------------------
      // 1. OUTFIELD & STADIUM ENVIRONMENT
      // ----------------------------------------------------
      // Outer stadium boundary grass gradient
      const grassGrad = ctx.createRadialGradient(225, 400, 50, 225, 400, 480);
      grassGrad.addColorStop(0, '#15803d'); // Vibrant lush green
      grassGrad.addColorStop(0.65, '#166534');
      grassGrad.addColorStop(1, '#0f3c22'); // Dark boundary shade
      ctx.fillStyle = grassGrad;
      ctx.fillRect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);

      // Outfield lawn mowing concentric cut circles
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 14;
      for (let r = 80; r < 460; r += 52) {
        ctx.beginPath();
        ctx.arc(225, 440, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Outer Oval Boundary Rope (Neon LED rope)
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(225, 430, 205, 360, 0, 0, Math.PI * 2);
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 3.5;
      ctx.shadowColor = '#4ade80';
      ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.restore();

      // Boundary sponsor cushion markers (spaced neon ticks)
      ctx.fillStyle = '#ffffff';
      for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 10) {
        const bx = 225 + Math.cos(angle) * 205;
        const by = 430 + Math.sin(angle) * 360;
        ctx.fillRect(bx - 3, by - 3, 6, 6);
      }

      // Stadium Grandstand / Crowd in upper quadrant
      ctx.save();
      ctx.fillStyle = '#0a1d12';
      ctx.beginPath();
      ctx.rect(0, 0, VIRTUAL_WIDTH, 140);
      ctx.fill();

      // Grandstand seating tiers
      for (let tier = 0; tier < 4; tier++) {
        const ty = 28 + tier * 26;
        ctx.fillStyle = tier % 2 === 0 ? 'rgba(30, 58, 41, 0.6)' : 'rgba(15, 34, 23, 0.6)';
        ctx.fillRect(10, ty, VIRTUAL_WIDTH - 20, 24);

        // Animated crowd heads
        for (let col = 0; col < 26; col++) {
          const cx = 20 + col * 16.5;
          const bounce = Math.sin(crowdWaveRef.current + col * 0.4 + tier) * 2;
          const colors = ['#f8fafc', '#38bdf8', '#fbbf24', '#f43f5e', '#a855f7'];
          ctx.fillStyle = colors[(col + tier) % colors.length];
          ctx.beginPath();
          ctx.arc(cx, ty + 12 + bounce, 3.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Stadium Floodlights (Glow cones)
      const drawFloodlight = (fx: number, fy: number, angleOffset: number) => {
        ctx.save();
        ctx.fillStyle = '#cbd5e1';
        ctx.fillRect(fx - 12, fy - 6, 24, 12);
        // Bright lamp bulbs
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#e0f2fe';
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.arc(fx - 6, fy, 4, 0, Math.PI * 2);
        ctx.arc(fx + 6, fy, 4, 0, Math.PI * 2);
        ctx.fill();

        // Beam gradient
        const beam = ctx.createRadialGradient(fx, fy, 5, fx + angleOffset, fy + 160, 220);
        beam.addColorStop(0, 'rgba(255, 255, 255, 0.22)');
        beam.addColorStop(0.5, 'rgba(255, 255, 255, 0.05)');
        beam.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = beam;
        ctx.beginPath();
        ctx.moveTo(fx - 14, fy);
        ctx.lineTo(fx + angleOffset - 120, fy + 380);
        ctx.lineTo(fx + angleOffset + 120, fy + 380);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      };

      drawFloodlight(45, 25, 60);
      drawFloodlight(VIRTUAL_WIDTH - 45, 25, -60);
      ctx.restore();

      // ----------------------------------------------------
      // 2. CRICKET PITCH (Center clay turf strip)
      // ----------------------------------------------------
      const pitchW = PITCH_CONFIG.width;
      const pitchX = 225 - pitchW / 2;
      const pitchH = PITCH_CONFIG.bottomY - PITCH_CONFIG.topY + 20;

      // Pitch clay body
      const pitchGrad = ctx.createLinearGradient(pitchX, 0, pitchX + pitchW, 0);
      pitchGrad.addColorStop(0, '#b4916c');
      pitchGrad.addColorStop(0.15, '#c9a87d');
      pitchGrad.addColorStop(0.5, '#deb887'); // Sandy clay turf
      pitchGrad.addColorStop(0.85, '#c9a87d');
      pitchGrad.addColorStop(1, '#b4916c');
      ctx.fillStyle = pitchGrad;
      ctx.fillRect(pitchX, PITCH_CONFIG.topY, pitchW, pitchH);

      // Pitch subtle turf cracks / wear lines
      ctx.strokeStyle = 'rgba(120, 80, 40, 0.2)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(pitchX + 22, 280);
      ctx.lineTo(pitchX + 28, 360);
      ctx.moveTo(pitchX + 68, 440);
      ctx.lineTo(pitchX + 64, 520);
      ctx.stroke();

      // Pitch Crease Markings (Crisp regulation lines)
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;

      // Bowler's bowling crease & return creases
      ctx.beginPath();
      ctx.moveTo(pitchX + 6, PITCH_CONFIG.bowlerCreaseY);
      ctx.lineTo(pitchX + pitchW - 6, PITCH_CONFIG.bowlerCreaseY);
      // Return creases
      ctx.moveTo(pitchX + 12, PITCH_CONFIG.bowlerCreaseY - 14);
      ctx.lineTo(pitchX + 12, PITCH_CONFIG.bowlerCreaseY + 14);
      ctx.moveTo(pitchX + pitchW - 12, PITCH_CONFIG.bowlerCreaseY - 14);
      ctx.lineTo(pitchX + pitchW - 12, PITCH_CONFIG.bowlerCreaseY + 14);
      ctx.stroke();

      // Batsman's Popping Crease & Return Creases
      ctx.beginPath();
      ctx.moveTo(pitchX + 6, PITCH_CONFIG.batsmanCreaseY);
      ctx.lineTo(pitchX + pitchW - 6, PITCH_CONFIG.batsmanCreaseY);
      ctx.moveTo(pitchX + 12, PITCH_CONFIG.batsmanCreaseY - 16);
      ctx.lineTo(pitchX + 12, PITCH_CONFIG.batsmanCreaseY + 18);
      ctx.moveTo(pitchX + pitchW - 12, PITCH_CONFIG.batsmanCreaseY - 16);
      ctx.lineTo(pitchX + pitchW - 12, PITCH_CONFIG.batsmanCreaseY + 18);
      ctx.stroke();

      // ----------------------------------------------------
      // 3. STUMPS & BAILS
      // ----------------------------------------------------
      // Bowler End Stumps
      ctx.fillStyle = '#fef08a';
      for (let s = -1; s <= 1; s++) {
        ctx.fillRect(225 + s * 6 - 1.5, PITCH_CONFIG.topStumpsY - 12, 3, 16);
      }
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(225 - 9, PITCH_CONFIG.topStumpsY - 14, 18, 3); // Bowler bails

      // Batsman End Stumps (With bails physics when bowled!)
      ctx.save();
      // Stumps shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(225, PITCH_CONFIG.stumpsY + 4, 14, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Three Stumps (Off, Middle, Leg)
      ctx.fillStyle = '#fef08a';
      for (let s = -1; s <= 1; s++) {
        const sx = 225 + s * 7;
        const sy = PITCH_CONFIG.stumpsY - 20;
        ctx.fillRect(sx - 2, sy, 4, 24);
      }

      // Bails
      if (!stumpsRef.current.bowled) {
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(225 - 11, PITCH_CONFIG.stumpsY - 23, 10, 3.5);
        ctx.fillRect(225 + 1, PITCH_CONFIG.stumpsY - 23, 10, 3.5);
      } else {
        // Flying bails animation
        stumpsRef.current.bails.forEach(bail => {
          bail.x += bail.vx;
          bail.y += bail.vy;
          bail.vy += 0.35; // gravity
          bail.rot += bail.vRot;

          ctx.save();
          ctx.translate(bail.x, bail.y);
          ctx.rotate(bail.rot);
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(-5, -2, 10, 4);
          ctx.restore();
        });
      }
      ctx.restore();

      // ----------------------------------------------------
      // 4. BATSMAN TIMING ARC / STRIKE ZONE FEEDBACK
      // ----------------------------------------------------
      if (phaseRef.current === 'ball_in_air_to_batsman') {
        ctx.save();
        const dist = ballRef.current.y - PITCH_CONFIG.perfectStrikeY;
        const inHitZone = Math.abs(dist) <= 45;

        // Visual Neon Strike Ring
        ctx.strokeStyle = inHitZone ? '#22c55e' : 'rgba(56, 189, 248, 0.4)';
        ctx.lineWidth = inHitZone ? 3.5 : 2;
        ctx.shadowColor = inHitZone ? '#4ade80' : 'transparent';
        ctx.shadowBlur = inHitZone ? 12 : 0;
        ctx.beginPath();
        ctx.ellipse(225, PITCH_CONFIG.perfectStrikeY, 44, 22, 0, 0, Math.PI * 2);
        ctx.stroke();

        // Timing helper tick marks
        ctx.fillStyle = inHitZone ? '#22c55e' : 'rgba(255, 255, 255, 0.4)';
        ctx.beginPath();
        ctx.arc(181, PITCH_CONFIG.perfectStrikeY, 3, 0, Math.PI * 2);
        ctx.arc(269, PITCH_CONFIG.perfectStrikeY, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Delivery Bounce Target Marker (Subtle indicator on pitch)
      if (phaseRef.current === 'bowler_runup' || phaseRef.current === 'ball_in_air_to_batsman') {
        const deliv = currentDeliveryRef.current;
        ctx.save();
        ctx.strokeStyle = deliv.color;
        ctx.lineWidth = 2.5;
        ctx.shadowColor = deliv.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(deliv.targetX, deliv.bounceY, 14, 0, Math.PI * 2);
        ctx.stroke();

        // Pulsing inner dot
        const pulse = Math.abs(Math.sin(Date.now() * 0.008));
        ctx.fillStyle = deliv.color;
        ctx.beginPath();
        ctx.arc(deliv.targetX, deliv.bounceY, 4 + pulse * 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // ----------------------------------------------------
      // 5. BOWLER SPRITE / ANIMATION
      // ----------------------------------------------------
      ctx.save();
      const bowler = bowlerRef.current;
      if (phaseRef.current === 'bowler_runup') {
        bowler.runupOffset += 1.8;
        bowler.armAngle += 0.22;
        if (bowler.runupOffset >= 0) {
          bowler.runupOffset = 0;
          bowler.isRunning = false;
          // Ball released!
          phaseRef.current = 'ball_in_air_to_batsman';
          setPhase('ball_in_air_to_batsman');
          setCanSwing(true);
        }
      }

      const bowlerY = PITCH_CONFIG.bowlerY + bowler.runupOffset;
      // Bowler shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(225, bowlerY + 22, 10, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Bowler body jersey (Dark navy/teal)
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(225, bowlerY + 6, 8, 0, Math.PI * 2); // Torso
      ctx.fill();

      // Head / Helmet
      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.arc(225, bowlerY - 6, 6, 0, Math.PI * 2);
      ctx.fill();

      // Bowling arm rotation
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(225, bowlerY);
      const armX = 225 + Math.cos(bowler.armAngle) * 14;
      const armY = bowlerY + Math.sin(bowler.armAngle) * 14;
      ctx.lineTo(armX, armY);
      ctx.stroke();
      ctx.restore();

      // ----------------------------------------------------
      // 6. FIELDERS (4 Outfield Sprites + Running AI)
      // ----------------------------------------------------
      fieldersRef.current.forEach(fielder => {
        // Move towards target
        const dx = fielder.targetX - fielder.x;
        const dy = fielder.targetY - fielder.y;
        const dist = Math.hypot(dx, dy);

        if (dist > 3) {
          fielder.x += (dx / dist) * fielder.speed;
          fielder.y += (dy / dist) * fielder.speed;
        }

        ctx.save();
        // Fielder shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
        ctx.beginPath();
        ctx.ellipse(fielder.x, fielder.y + 10, 8, 3.5, 0, 0, Math.PI * 2);
        ctx.fill();

        // Fielder jersey
        ctx.fillStyle = fielder.color;
        ctx.beginPath();
        ctx.arc(fielder.x, fielder.y, 7, 0, Math.PI * 2);
        ctx.fill();

        // Fielder cap / head
        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.arc(fielder.x, fielder.y - 6, 5, 0, Math.PI * 2);
        ctx.fill();

        // Catch range indicator when ball is in play
        if (phaseRef.current === 'ball_struck' && ballRef.current.inAirTrajectory) {
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(fielder.x, fielder.y, fielder.radius, 0, Math.PI * 2);
          ctx.stroke();
        }

        ctx.restore();
      });

      // ----------------------------------------------------
      // 7. BATSMAN SPRITE & SWING ANIMATION
      // ----------------------------------------------------
      ctx.save();
      const batsman = batsmanRef.current;
      const bx = batsman.x;
      const by = batsman.y;

      // Batsman shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
      ctx.beginPath();
      ctx.ellipse(bx, by + 16, 14, 5, 0, 0, Math.PI * 2);
      ctx.fill();

      // Batsman Pads (Legs)
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(bx - 8, by + 4, 6, 12);
      ctx.fillRect(bx + 2, by + 4, 6, 12);

      // Batsman Jersey (Bright Golden Yellow Team Kit)
      ctx.fillStyle = '#eab308';
      ctx.beginPath();
      ctx.arc(bx, by, 10, 0, Math.PI * 2);
      ctx.fill();

      // Helmet (Deep Royal Blue)
      ctx.fillStyle = '#1e3a8a';
      ctx.beginPath();
      ctx.arc(bx, by - 12, 7.5, 0, Math.PI * 2);
      ctx.fill();
      // Helmet grille / visor
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(bx - 3, by - 9);
      ctx.lineTo(bx + 5, by - 9);
      ctx.stroke();

      // Cricket Bat & Swing
      let batAngle = 0.8; // Default ready stance backlift
      if (batsman.stance === 'swing_left') {
        batAngle = -2.4 + (1 - batsman.swingProgress) * 1.6;
      } else if (batsman.stance === 'swing_straight') {
        batAngle = -1.55 + (1 - batsman.swingProgress) * 1.4;
      } else if (batsman.stance === 'swing_right') {
        batAngle = -0.7 + (1 - batsman.swingProgress) * 1.5;
      }

      if (batsman.swingProgress > 0) {
        batsman.swingProgress = Math.max(0, batsman.swingProgress - 0.08);
      }

      ctx.save();
      ctx.translate(bx + 4, by);
      ctx.rotate(batAngle);
      // Bat handle
      ctx.strokeStyle = '#f8fafc';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -10);
      ctx.stroke();
      // Bat blade (English willow wood tone)
      ctx.fillStyle = '#d97706';
      ctx.fillRect(-2.5, -34, 5, 24);
      // Bat grip / sticker
      ctx.fillStyle = '#2563eb';
      ctx.fillRect(-2.5, -20, 5, 5);
      ctx.restore();

      ctx.restore();

      // ----------------------------------------------------
      // 8. BALL PHYSICS & TRAJECTORY UPDATES
      // ----------------------------------------------------
      const ball = ballRef.current;

      // PHASE A: BALL TRAVELING FROM BOWLER TO BATSMAN
      if (phaseRef.current === 'ball_in_air_to_batsman') {
        const deliv = currentDeliveryRef.current;
        const speed = (deliv.speedKmh / 140) * 8.5 * ball.speedMultiplier;

        ball.y += speed;

        // Apply swing / cutter lateral curve
        if (ball.y < deliv.bounceY) {
          // In air before bounce: drift towards target
          const progressToBounce = (ball.y - PITCH_CONFIG.bowlerY) / (deliv.bounceY - PITCH_CONFIG.bowlerY);
          ball.x = 225 + (deliv.targetX - 225) * progressToBounce;
        } else {
          // Bounced on pitch!
          if (!ball.bounced) {
            ball.bounced = true;
            sounds.playBounce();
            spawnParticles(ball.x, ball.y, 8, ['#d97706', '#b45309'], 'dust');
          }
          // After bounce: curve / seam deviation
          const postBounceProgress = (ball.y - deliv.bounceY) / (PITCH_CONFIG.batsmanCreaseY - deliv.bounceY);
          ball.x = deliv.targetX + deliv.curveX * Math.min(1.0, postBounceProgress);
        }

        // Store trail
        ballTrailsRef.current.push({
          x: ball.x,
          y: ball.y,
          z: 0,
          alpha: 0.6,
          radius: 4,
        });

        // Check if ball passed batsman without hit (Bowled or Dot)
        if (ball.y > PITCH_CONFIG.batsmanCreaseY + 28 && !ball.shotHit) {
          // Check Bowled condition
          const distToStumps = Math.abs(ball.x - 225);
          if (distToStumps <= 14) {
            // BOWLED!!
            stumpsRef.current.bowled = true;
            stumpsRef.current.bails[0].vx = -3.5 + Math.random() * 2;
            stumpsRef.current.bails[0].vy = -6;
            stumpsRef.current.bails[0].vRot = -0.3;
            stumpsRef.current.bails[1].vx = 3.5 + Math.random() * 2;
            stumpsRef.current.bails[1].vy = -7;
            stumpsRef.current.bails[1].vRot = 0.3;

            sounds.playWicket();
            triggerScreenShake(14);
            spawnParticles(225, PITCH_CONFIG.stumpsY, 25, ['#f59e0b', '#ffffff'], 'sparks');
            addFloatingText('CLEAN BOWLED!!', 225, PITCH_CONFIG.stumpsY - 40, '#ef4444', 'Off-stump uprooted!');
            handleBallOutcome('bowled', 0);
          } else {
            // DOT BALL (Beaten outside off or down leg)
            sounds.playMiss();
            addFloatingText('DOT BALL', 225, PITCH_CONFIG.batsmanCreaseY - 20, '#94a3b8');
            handleBallOutcome('dot', 0);
          }
        }
      }

      // PHASE B: BALL HIT AND FLYING / ROLLING ACROSS OUTFIELD
      if (phaseRef.current === 'ball_struck') {
        ball.x += ball.vx;
        ball.y += ball.vy;

        // In air z-height calculation
        if (ball.inAirTrajectory) {
          ball.z += ball.vz;
          ball.vz -= ball.gravity;

          // Ball bounced on grass outfield
          if (ball.z <= 0) {
            ball.z = 0;
            ball.hitBouncedOnOutfield = true;
            ball.vz = -ball.vz * 0.40; // Dampened bounce
            if (Math.abs(ball.vz) < 0.8) {
              ball.inAirTrajectory = false;
              ball.vz = 0;
            }
            sounds.playBounce();
            spawnParticles(ball.x, ball.y, 6, ['#15803d', '#22c55e'], 'dust');
          }
        } else {
          // Ball rolling on grass with authentic turf friction
          ball.vx *= 0.988;
          ball.vy *= 0.988;
        }

        // Store trail
        ballTrailsRef.current.push({
          x: ball.x,
          y: ball.y - ball.z,
          z: ball.z,
          alpha: ball.isLofted ? 0.8 : 0.45,
          radius: 5 + Math.min(6, ball.z * 0.15),
        });

        // Check Fielder Collision (Catch or Ground Stop)
        let interceptedByFielder: Fielder | null = null;
        fieldersRef.current.forEach(f => {
          const distToFielder = Math.hypot(ball.x - f.x, ball.y - f.y);
          if (distToFielder < f.radius + 6) {
            interceptedByFielder = f;
          }
        });

        if (interceptedByFielder && !ball.isOut) {
          const f = interceptedByFielder as Fielder;
          // Aerial catch: only if ball is lofted and has NEVER bounced on the ground
          if (ball.isLofted && !ball.hitBouncedOnOutfield && ball.z > 6 && ball.z < 45) {
            // CAUGHT OUT!!
            ball.isOut = true;
            ball.vx = 0;
            ball.vy = 0;
            ball.vz = 0;
            sounds.playWicket();
            triggerScreenShake(10);
            spawnParticles(f.x, f.y, 25, ['#ef4444', '#f8fafc'], 'sparks');
            addFloatingText('CAUGHT OUT!!', f.x, f.y - 30, '#ef4444', `${f.name} takes the catch!`);
            handleBallOutcome('caught', 0);
          } else if (ball.z <= 6) {
            // Ground fielding:
            // A hard shot hit into the gap beats the diving fielder!
            const currentSpeed = Math.hypot(ball.vx, ball.vy);
            const distToCenter = Math.hypot(ball.x - f.x, ball.y - f.y);

            // Clean stop if ball is directly in fielder's grasp or slowed down
            if (currentSpeed < 9.0 || distToCenter < f.radius - 3) {
              ball.vx = 0;
              ball.vy = 0;
              const distFromCrease = Math.hypot(ball.x - 225, ball.y - PITCH_CONFIG.batsmanCreaseY);
              const runsAwarded = distFromCrease > 240 ? 3 : distFromCrease > 140 ? 2 : 1;
              const outcomeKey = runsAwarded === 3 ? 'runs_3' : runsAwarded === 2 ? 'runs_2' : 'runs_1';
              
              addFloatingText(`${runsAwarded} RUN${runsAwarded > 1 ? 'S' : ''}`, ball.x, ball.y - 25, '#38bdf8', 'Stopped inside the ring');
              handleBallOutcome(outcomeKey, runsAwarded);
            }
          }
        }

        // Check Boundary Collision
        // Elliptical boundary check (centered at 225, 430 with radii 205, 360)
        const normX = (ball.x - 225) / 205;
        const normY = (ball.y - 430) / 360;
        const distToBoundaryCenter = normX * normX + normY * normY;

        if (distToBoundaryCenter >= 1.0 && !ball.isOut) {
          ball.isOut = true;
          ball.vx = 0;
          ball.vy = 0;

          // REALISTIC CRICKET RULES:
          // A SIX is ONLY awarded when the ball cleared the boundary rope ON THE FULL in the air (never bounced on outfield)!
          const isSixOnTheFull = ball.isLofted && !ball.hitBouncedOnOutfield && ball.z > 0 && ball.shotPower >= 14.5;

          if (isSixOnTheFull) {
            // SIX RUNS!! In air over the ropes!
            sounds.playCheer('six');
            triggerScreenShake(15);
            spawnParticles(ball.x, ball.y, 60, ['#eab308', '#f97316', '#3b82f6', '#ec4899', '#ffffff'], 'confetti');
            addFloatingText('MASSIVE SIX!! 🚀', 225, 360, '#facc15', 'Cleared the boundary rope on the full!');
            handleBallOutcome('six', 6);
          } else {
            // FOUR RUNS! Rolling along the turf or bounced inside before crossing!
            sounds.playCheer('four');
            triggerScreenShake(8);
            spawnParticles(ball.x, ball.y, 40, ['#22c55e', '#38bdf8', '#ffffff'], 'confetti');
            addFloatingText('CRACKING FOUR! 🏏', 225, 360, '#4ade80', ball.hitBouncedOnOutfield ? 'Bounced over the boundary rope!' : 'Pierced the outfield gap to the fence!');
            handleBallOutcome('four', 4);
          }
        }

        // Ball stopped moving without reaching boundary (fielders chase)
        if (Math.abs(ball.vx) < 0.2 && Math.abs(ball.vy) < 0.2 && ball.z <= 0 && !ball.isOut) {
          ball.isOut = true;
          const distFromCrease = Math.hypot(ball.x - 225, ball.y - PITCH_CONFIG.batsmanCreaseY);
          const runsAwarded = distFromCrease > 200 ? 2 : 1;
          const outcomeKey = runsAwarded === 2 ? 'runs_2' : 'runs_1';
          addFloatingText(`${runsAwarded} RUN${runsAwarded > 1 ? 'S' : ''}`, ball.x, ball.y - 25, '#38bdf8');
          handleBallOutcome(outcomeKey, runsAwarded);
        }
      }

      // ----------------------------------------------------
      // 9. DRAW BALL TRAILS & GLOW
      // ----------------------------------------------------
      ctx.save();
      for (let i = ballTrailsRef.current.length - 1; i >= 0; i--) {
        const trail = ballTrailsRef.current[i];
        trail.alpha -= 0.045;
        if (trail.alpha <= 0) {
          ballTrailsRef.current.splice(i, 1);
          continue;
        }

        ctx.fillStyle = `rgba(250, 204, 21, ${trail.alpha * 0.4})`;
        ctx.beginPath();
        ctx.arc(trail.x, trail.y, trail.radius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // ----------------------------------------------------
      // 10. DRAW BALL & BALL SHADOW
      // ----------------------------------------------------
      if (phaseRef.current === 'ball_in_air_to_batsman' || phaseRef.current === 'ball_struck') {
        const currentBallZ = ball.z;
        const ballDrawY = ball.y - currentBallZ;

        // Ground shadow
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        const shadowScale = Math.max(0.3, 1 - currentBallZ * 0.015);
        ctx.beginPath();
        ctx.ellipse(ball.x, ball.y, 6 * shadowScale, 3 * shadowScale, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // White leather cricket ball with red seam
        ctx.save();
        const ballSize = 6.5 + Math.min(8, currentBallZ * 0.12);
        ctx.shadowColor = '#ffffff';
        ctx.shadowBlur = phaseRef.current === 'ball_struck' ? 12 : 4;

        // Ball Body
        const ballGrad = ctx.createRadialGradient(
          ball.x - 2, ballDrawY - 2, 1,
          ball.x, ballDrawY, ballSize
        );
        ballGrad.addColorStop(0, '#ffffff');
        ballGrad.addColorStop(0.7, '#f8fafc');
        ballGrad.addColorStop(1, '#cbd5e1');
        ctx.fillStyle = ballGrad;
        ctx.beginPath();
        ctx.arc(ball.x, ballDrawY, ballSize, 0, Math.PI * 2);
        ctx.fill();

        // Seam stitch
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.arc(ball.x, ballDrawY, ballSize - 1, 0.2, Math.PI - 0.2);
        ctx.stroke();
        ctx.restore();
      }

      // ----------------------------------------------------
      // 11. SPEED LINES VFX (SIX BURST)
      // ----------------------------------------------------
      if (speedLinesRef.current.active) {
        ctx.save();
        speedLinesRef.current.opacity -= 0.025;
        if (speedLinesRef.current.opacity <= 0) {
          speedLinesRef.current.active = false;
        }

        ctx.strokeStyle = `rgba(255, 255, 255, ${speedLinesRef.current.opacity * 0.5})`;
        ctx.lineWidth = 2;
        const centerX = 225;
        const centerY = 400;

        for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 12) {
          const innerR = 120;
          const outerR = 480;
          ctx.beginPath();
          ctx.moveTo(centerX + Math.cos(angle) * innerR, centerY + Math.sin(angle) * innerR);
          ctx.lineTo(centerX + Math.cos(angle) * outerR, centerY + Math.sin(angle) * outerR);
          ctx.stroke();
        }
        ctx.restore();
      }

      // ----------------------------------------------------
      // 12. DRAW PARTICLES (Sparks & Confetti)
      // ----------------------------------------------------
      ctx.save();
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        p.alpha = 1 - p.life / p.maxLife;

        if (p.life >= p.maxLife) {
          particlesRef.current.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.translate(p.x, p.y);
        if (p.rotation !== undefined && p.vRot !== undefined) {
          p.rotation += p.vRot;
          ctx.rotate(p.rotation);
        }

        ctx.fillStyle = p.color;
        if (p.shape === 'rect') {
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }
      ctx.restore();

      // ----------------------------------------------------
      // 13. FLOATING ARCADE TEXTS ("SIX!!", "PERFECT!", etc.)
      // ----------------------------------------------------
      ctx.save();
      for (let i = floatingTextsRef.current.length - 1; i >= 0; i--) {
        const ft = floatingTextsRef.current[i];
        ft.y += ft.vy;
        ft.scale = Math.max(1.0, ft.scale - 0.02);
        ft.life++;
        ft.alpha = Math.max(0, 1 - ft.life / 65);

        if (ft.life >= 65) {
          floatingTextsRef.current.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.globalAlpha = ft.alpha;
        ctx.translate(ft.x, ft.y);
        ctx.scale(ft.scale, ft.scale);
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        // Main text shadow
        ctx.font = '900 28px system-ui, -apple-system, sans-serif';
        ctx.fillStyle = '#0f172a';
        ctx.fillText(ft.text, 2, 2);

        // Main text
        ctx.fillStyle = ft.color;
        ctx.fillText(ft.text, 0, 0);

        // Subtext if present
        if (ft.subtext) {
          ctx.font = '600 13px system-ui, -apple-system, sans-serif';
          ctx.fillStyle = '#f8fafc';
          ctx.fillText(ft.subtext, 0, 24);
        }

        ctx.restore();
      }
      ctx.restore();

      // ----------------------------------------------------
      // 14. TOUCH SWIPE GESTURE TRAIL OVERLAY
      // ----------------------------------------------------
      if (touchStartPos.current && touchCurrentPos.current) {
        ctx.save();
        const start = touchStartPos.current;
        const curr = touchCurrentPos.current;
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 4;
        ctx.shadowColor = '#0284c7';
        ctx.shadowBlur = 10;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(start.x, start.y);
        ctx.lineTo(curr.x, curr.y);
        ctx.stroke();

        // Arrow head
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(curr.x, curr.y, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      ctx.restore(); // Restore shake transform

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [handleBallOutcome]);

  // Touch and Mouse Event Handlers with coordinate scaling
  const getCanvasCoords = useCallback((clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = VIRTUAL_WIDTH / rect.width;
    const scaleY = VIRTUAL_HEIGHT / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }, []);

  const handlePointerDown = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    if (phaseRef.current === 'ready_to_bowl') {
      startBowling();
      return;
    }
    const coords = getCanvasCoords(e.clientX, e.clientY);
    touchStartPos.current = { x: coords.x, y: coords.y, time: Date.now() };
    touchCurrentPos.current = { x: coords.x, y: coords.y };
  }, [getCanvasCoords, startBowling]);

  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!touchStartPos.current) return;
    const coords = getCanvasCoords(e.clientX, e.clientY);
    touchCurrentPos.current = { x: coords.x, y: coords.y };
  }, [getCanvasCoords]);

  const handlePointerUp = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!touchStartPos.current) return;
    const coords = getCanvasCoords(e.clientX, e.clientY);
    const start = touchStartPos.current;
    const dx = coords.x - start.x;
    const dy = coords.y - start.y;
    const dist = Math.hypot(dx, dy);

    touchStartPos.current = null;
    touchCurrentPos.current = null;

    // Minimum swipe threshold (18 virtual pixels)
    if (dist < 18) {
      // Tap default -> Straight drive
      executeSwing('straight');
      return;
    }

    // Dynamic swipe loft detection:
    // A steep upward swipe (dy < -45) automatically triggers a lofted aerial shot!
    const isLoftSwipe = dy < -45 ? true : undefined;

    // Direction calculation:
    // dx < -25 -> Left (Pull / Leg shot)
    // dx > 25 -> Right (Cover / Cut shot)
    // otherwise -> Straight drive
    if (dx < -25) {
      executeSwing('left', isLoftSwipe);
    } else if (dx > 25) {
      executeSwing('right', isLoftSwipe);
    } else {
      executeSwing('straight', isLoftSwipe);
    }
  }, [executeSwing, getCanvasCoords]);

  // Keyboard controls for desktop testing: Left arrow / A = Left, Up / W = Straight, Right / D = Right, L = Toggle Loft
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'l' || e.key === 'L') {
        setShotMode(prev => prev === 'ground' ? 'loft' : 'ground');
        sounds.playClick();
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        executeSwing('left');
      } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W' || e.key === ' ') {
        executeSwing('straight');
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        executeSwing('right');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [executeSwing]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center select-none touch-none bg-slate-950 overflow-hidden p-1">
      {/* Canvas Viewport Frame: dynamically fits available height and width while maintaining 9:16 aspect */}
      <div 
        className="relative flex items-center justify-center shadow-2xl rounded-2xl overflow-hidden border border-slate-800 bg-slate-900"
        style={{
          height: '100%',
          aspectRatio: '9 / 16',
          maxHeight: '100%',
          maxWidth: '100%',
        }}
      >
        <canvas
          ref={canvasRef}
          width={VIRTUAL_WIDTH}
          height={VIRTUAL_HEIGHT}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={() => {
            touchStartPos.current = null;
            touchCurrentPos.current = null;
          }}
          className="w-full h-full block object-contain cursor-crosshair touch-none"
        />

        {/* Floating Controls / HUD overlays on canvas */}
        {/* Top Control Bar Buttons */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5 z-20">
          <button
            onClick={() => {
              sounds.playClick();
              onShareGame();
            }}
            title="Share Game Link"
            className="w-8 h-8 rounded-full bg-emerald-600/90 hover:bg-emerald-500 backdrop-blur border border-emerald-400/80 flex items-center justify-center text-white text-xs font-bold transition-all shadow-lg active:scale-95"
          >
            🔗
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onToggleMute();
            }}
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            className="w-8 h-8 rounded-full bg-slate-900/80 backdrop-blur border border-slate-700/80 flex items-center justify-center text-slate-200 hover:text-white hover:bg-slate-800 transition-colors shadow-lg"
          >
            {isMuted ? '🔇' : '🔊'}
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onShowHowToPlay();
            }}
            title="How to Play"
            className="w-8 h-8 rounded-full bg-slate-900/80 backdrop-blur border border-slate-700/80 flex items-center justify-center text-xs font-bold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors shadow-lg"
          >
            ?
          </button>
          <button
            onClick={() => {
              sounds.playClick();
              onRestartMatch();
            }}
            title="Restart Match"
            className="w-8 h-8 rounded-full bg-slate-900/80 backdrop-blur border border-slate-700/80 flex items-center justify-center text-xs font-bold text-slate-200 hover:text-white hover:bg-slate-800 transition-colors shadow-lg"
          >
            ↺
          </button>
        </div>

        {/* Live Delivery Info Indicator */}
        <div className="absolute top-3 left-3 z-20 flex items-center gap-2 bg-slate-900/85 backdrop-blur border border-slate-700/80 px-2.5 py-1 rounded-lg text-xs shadow-lg">
          <span 
            className="w-2.5 h-2.5 rounded-full inline-block animate-pulse"
            style={{ backgroundColor: currentDelivery.color }}
          />
          <span className="font-medium text-slate-200">{currentDelivery.name}</span>
          <span className="text-slate-400 font-mono text-[10px]">{currentDelivery.speedKmh} km/h</span>
        </div>

        {/* Bowl Delivery Trigger Overlay */}
        {phase === 'ready_to_bowl' && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-4 bg-black/25 pointer-events-auto">
            <button
              onClick={startBowling}
              className="py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-white font-black text-sm tracking-wide shadow-xl shadow-emerald-500/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2.5 border border-emerald-300/40 animate-pulse cursor-pointer"
            >
              <span className="text-xl">🏏</span>
              <div className="text-left">
                <div className="text-xs uppercase font-extrabold tracking-wider">
                  BOWL BALL {stats.ballsBowled + 1} OF {stats.totalBalls}
                </div>
                <div className="text-[10px] text-emerald-100 font-medium">
                  {currentDelivery.name} · {currentDelivery.speedKmh} km/h
                </div>
              </div>
              <span className="text-lg">⚡</span>
            </button>
            <div className="mt-2 text-[11px] font-semibold text-white drop-shadow bg-slate-950/70 px-3 py-1 rounded-full border border-slate-700/60">
              Tap button or field to bowl · Swipe to hit
            </div>
          </div>
        )}

        {/* Batting Timing Helper Prompt when ready */}
        {phase === 'ball_in_air_to_batsman' && (
          <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 pointer-events-none animate-bounce bg-slate-900/90 border border-emerald-500/60 text-emerald-400 text-xs font-bold px-3 py-1 rounded-full shadow-lg">
            ⚡ SWIPE NOW!
          </div>
        )}

        {/* Ground vs Loft Mode Selector */}
        <div className="absolute bottom-16 left-0 right-0 px-4 flex items-center justify-center gap-2 z-20 pointer-events-auto">
          <button
            onClick={() => {
              sounds.playClick();
              setShotMode('ground');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 border active:scale-95 ${
              shotMode === 'ground'
                ? 'bg-emerald-600 border-emerald-400 text-white shadow-emerald-950/60 ring-2 ring-emerald-300/60 scale-102'
                : 'bg-slate-900/90 border-slate-700/80 text-slate-400 hover:text-white'
            }`}
          >
            <span>🎯</span>
            <span>GROUND (Hits 4s)</span>
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              setShotMode('loft');
            }}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 border active:scale-95 ${
              shotMode === 'loft'
                ? 'bg-amber-600 border-amber-400 text-white shadow-amber-950/60 ring-2 ring-amber-300/60 scale-102'
                : 'bg-slate-900/90 border-slate-700/80 text-slate-400 hover:text-white'
            }`}
          >
            <span>🚀</span>
            <span>LOFT (Hits 6s)</span>
          </button>
        </div>

        {/* Quick Batting Touch Action Buttons for accessibility and mobile convenience */}
        <div className="absolute bottom-2 left-0 right-0 px-4 flex items-center justify-between gap-2 z-20 pointer-events-auto">
          <button
            onClick={() => executeSwing('left')}
            disabled={!canSwing}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95 flex flex-col items-center justify-center ${
              canSwing 
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/40 ring-1 ring-emerald-400/50' 
                : 'bg-slate-800/70 text-slate-400 opacity-60'
            }`}
          >
            <span className="text-sm">⬅️</span>
            <span>PULL</span>
            <span className="text-[9px] text-emerald-200/90 font-normal">
              {shotMode === 'loft' ? 'Lofted Mid-Wkt' : 'Ground Glance'}
            </span>
          </button>

          <button
            onClick={() => executeSwing('straight')}
            disabled={!canSwing}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95 flex flex-col items-center justify-center ${
              canSwing 
                ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-900/40 ring-1 ring-amber-400/50' 
                : 'bg-slate-800/70 text-slate-400 opacity-60'
            }`}
          >
            <span className="text-sm">⬆️</span>
            <span>DRIVE</span>
            <span className="text-[9px] text-amber-200/90 font-normal">
              {shotMode === 'loft' ? 'Lofted Straight' : 'Turf Drive'}
            </span>
          </button>

          <button
            onClick={() => executeSwing('right')}
            disabled={!canSwing}
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition-all shadow-lg active:scale-95 flex flex-col items-center justify-center ${
              canSwing 
                ? 'bg-sky-600 hover:bg-sky-500 text-white shadow-sky-900/40 ring-1 ring-sky-400/50' 
                : 'bg-slate-800/70 text-slate-400 opacity-60'
            }`}
          >
            <span className="text-sm">➡️</span>
            <span>COVER</span>
            <span className="text-[9px] text-sky-200/90 font-normal">
              {shotMode === 'loft' ? 'Lofted Cut' : 'Turf Cover Drive'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
