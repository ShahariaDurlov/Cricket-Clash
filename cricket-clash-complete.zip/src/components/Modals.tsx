import React from 'react';
import { GameStats, GameDifficulty } from '../types';
import { DIFFICULTY_CONFIG } from '../constants';
import { sounds } from '../audio';

interface StartModalProps {
  isOpen: boolean;
  onStart: (diff: GameDifficulty) => void;
  selectedDifficulty: GameDifficulty;
  onSelectDifficulty: (diff: GameDifficulty) => void;
}

export const StartModal: React.FC<StartModalProps> = ({
  isOpen,
  onStart,
  selectedDifficulty,
  onSelectDifficulty,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-emerald-500/40 rounded-2xl p-6 shadow-2xl text-slate-100 flex flex-col items-center text-center">
        {/* Neon Badge */}
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-amber-500 p-0.5 shadow-lg shadow-emerald-500/20 mb-3 flex items-center justify-center">
          <span className="text-3xl">🏏</span>
        </div>

        <h1 className="text-2xl font-black text-white tracking-wide uppercase">
          Cricket Clash
        </h1>
        <div className="text-xs font-bold text-emerald-400 tracking-wider mb-2">
          SUPER OVER CHALLENGE
        </div>

        <p className="text-xs text-slate-300 leading-relaxed mb-4">
          Step into the batting crease under the stadium floodlights! Time your shots to perfection and chase the target in 6 balls.
        </p>

        {/* Difficulty Selection */}
        <div className="w-full mb-4">
          <div className="text-[11px] font-semibold text-slate-400 mb-1.5 text-left">
            SELECT TARGET DIFFICULTY:
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {(['rookie', 'pro', 'legend'] as GameDifficulty[]).map((diff) => {
              const active = selectedDifficulty === diff;
              const cfg = DIFFICULTY_CONFIG[diff];
              return (
                <button
                  key={diff}
                  onClick={() => {
                    sounds.playClick();
                    onSelectDifficulty(diff);
                  }}
                  className={`py-2 px-1 rounded-xl text-xs font-bold transition-all border ${
                    active
                      ? 'bg-emerald-600 border-emerald-400 text-white shadow-md shadow-emerald-900/50 scale-102'
                      : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="uppercase">{diff}</div>
                  <div className="text-[10px] font-normal opacity-90">{cfg.target} Runs</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Quick Controls Cheat Sheet */}
        <div className="w-full bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-5 text-left text-xs space-y-1.5">
          <div className="font-semibold text-slate-300 text-[11px]">CONTROLS:</div>
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <span className="text-emerald-400 font-bold">⬅️ SWIPE LEFT:</span>
            <span>Pull Shot to Deep Mid-Wicket</span>
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <span className="text-amber-400 font-bold">⬆️ SWIPE UP / TAP:</span>
            <span>Straight Lofted Drive</span>
          </div>
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <span className="text-sky-400 font-bold">➡️ SWIPE RIGHT:</span>
            <span>Cover Drive into Off-Side</span>
          </div>
        </div>

        {/* Start Button */}
        <button
          onClick={() => {
            sounds.playClick();
            onStart(selectedDifficulty);
          }}
          className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-white font-black text-sm tracking-wide shadow-lg shadow-emerald-500/30 hover:brightness-110 active:scale-98 transition-all"
        >
          START SUPER OVER ⚡
        </button>
      </div>
    </div>
  );
};

interface ResultModalProps {
  isOpen: boolean;
  won: boolean;
  stats: GameStats;
  difficulty: GameDifficulty;
  onReplay: () => void;
  onChangeDifficulty: () => void;
  onShare: () => void;
}

export const ResultModal: React.FC<ResultModalProps> = ({
  isOpen,
  won,
  stats,
  difficulty,
  onReplay,
  onChangeDifficulty,
  onShare,
}) => {
  if (!isOpen) return null;

  const runsNeeded = Math.max(0, stats.targetRuns - stats.totalRuns);
  const strikeRate = stats.ballsBowled > 0 ? ((stats.totalRuns / stats.ballsBowled) * 100).toFixed(0) : '0';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className={`w-full max-w-sm bg-slate-900 border rounded-2xl p-6 shadow-2xl text-slate-100 flex flex-col items-center text-center ${
        won ? 'border-emerald-500/60 shadow-emerald-950/60' : 'border-red-500/60 shadow-red-950/60'
      }`}>
        {/* Result Icon */}
        <div className={`w-16 h-16 rounded-full flex items-center justify-center text-3xl mb-3 shadow-lg ${
          won ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' : 'bg-red-500/20 text-red-400 border border-red-500/50'
        }`}>
          {won ? '🏆' : '💔'}
        </div>

        <h2 className="text-2xl font-black text-white tracking-wide uppercase">
          {won ? 'CHAMPION VICTORY!' : 'SUPER OVER DEFEAT'}
        </h2>

        <div className={`text-xs font-bold tracking-wider mb-4 ${won ? 'text-emerald-400' : 'text-red-400'}`}>
          {won 
            ? `TARGET REACHED WITH ${stats.maxWickets - stats.wicketsLost} WICKET(S) IN HAND!`
            : runsNeeded > 0 ? `FELL SHORT BY ${runsNeeded} RUN(S)` : 'ALL WICKETS LOST!'}
        </div>

        {/* Match Summary Box */}
        <div className="w-full bg-slate-950/80 border border-slate-800 rounded-xl p-4 mb-4 text-left">
          <div className="text-[11px] font-semibold text-slate-400 mb-2 border-b border-slate-800 pb-1">
            SUPER OVER SCORECARD:
          </div>

          <div className="grid grid-cols-2 gap-y-2 text-xs">
            <div>
              <span className="text-slate-400">Total Score:</span>{' '}
              <strong className="text-white">{stats.totalRuns} / {stats.wicketsLost}</strong>
            </div>
            <div>
              <span className="text-slate-400">Balls Faced:</span>{' '}
              <strong className="text-white">{stats.ballsBowled} / {stats.totalBalls}</strong>
            </div>
            <div>
              <span className="text-slate-400">Boundaries:</span>{' '}
              <strong className="text-emerald-400">{stats.foursCount} (4s)</strong> · <strong className="text-amber-400">{stats.sixesCount} (6s)</strong>
            </div>
            <div>
              <span className="text-slate-400">Strike Rate:</span>{' '}
              <strong className="text-sky-400">{strikeRate}</strong>
            </div>
          </div>

          {stats.highestShotSpeed > 0 && (
            <div className="mt-2 pt-2 border-t border-slate-800/80 text-[11px] text-slate-300">
              🚀 Top Shot Speed: <strong className="text-amber-400">{stats.highestShotSpeed} km/h</strong>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          <button
            onClick={() => {
              sounds.playClick();
              onReplay();
            }}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-bold text-sm shadow-lg shadow-emerald-500/20 hover:brightness-110 active:scale-98 transition-all"
          >
            PLAY AGAIN ↺
          </button>

          <button
            onClick={() => {
              sounds.playClick();
              onShare();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-900/40 flex items-center justify-center gap-1.5 transition-all"
          >
            <span>🔗</span>
            <span>SHARE CHALLENGE LINK</span>
          </button>

          <a
            href="/cricket-clash-complete.zip"
            download="cricket-clash-complete.zip"
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>💾</span>
            <span>DOWNLOAD GAME ZIP</span>
          </a>

          <button
            onClick={() => {
              sounds.playClick();
              onChangeDifficulty();
            }}
            className="w-full py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold border border-slate-800 transition-colors"
          >
            CHANGE DIFFICULTY
          </button>
        </div>
      </div>
    </div>
  );
};

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-5 shadow-2xl text-slate-100 flex flex-col max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
          <h3 className="text-base font-black text-white">HOW TO PLAY & SAVE</h3>
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="text-slate-400 hover:text-white text-lg font-bold w-6 h-6 flex items-center justify-center"
          >
            ✕
          </button>
        </div>

        <div className="space-y-3.5 text-xs text-slate-300 leading-relaxed">
          <div>
            <h4 className="font-bold text-emerald-400 mb-0.5">1. THE TIMING ZONE</h4>
            <p className="text-slate-400 text-[11px]">
              Watch the ball as it travels down the pitch. A neon circle highlights the crease. Strike when the ball is right inside this circle for <strong>PERFECT TIMING</strong>!
            </p>
          </div>

          <div>
            <h4 className="font-bold text-amber-400 mb-0.5">2. SHOT DIRECTION & SWIPE</h4>
            <p className="text-slate-400 text-[11px]">
              Swipe across the canvas or use the bottom action buttons:
            </p>
            <ul className="mt-1 space-y-0.5 text-[11px] list-disc list-inside text-slate-300">
              <li><strong>Swipe Left:</strong> Pull shot to Deep Mid-Wicket.</li>
              <li><strong>Swipe Up / Tap:</strong> Straight drive down the ground.</li>
              <li><strong>Swipe Right:</strong> Cover drive into the off side.</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-sky-400 mb-0.5">3. BOWLING VARIATIONS</h4>
            <p className="text-slate-400 text-[11px]">
              The colored indicator on the pitch reveals the delivery type (Fast, Cutter, In-swinger, Out-swinger, Yorker).
            </p>
          </div>

          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <h4 className="font-bold text-teal-400 mb-1 flex items-center gap-1.5">
              <span>💾</span>
              <span>SAVE & CONVERT TO ANDROID APK</span>
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed mb-2">
              You can download the full project archive directly below or through AI Studio's top-right menu to run offline or convert into an APK using WebIntoApp.com, Cordova, or Capacitor.
            </p>
            <a
              href="/cricket-clash-complete.zip"
              download="cricket-clash-complete.zip"
              className="w-full py-2 px-3 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors text-center"
            >
              <span>📥</span>
              <span>Download Complete ZIP Package</span>
            </a>
          </div>
        </div>

        <button
          onClick={() => {
            sounds.playClick();
            onClose();
          }}
          className="mt-4 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700"
        >
          BACK TO GAME
        </button>
      </div>
    </div>
  );
};
