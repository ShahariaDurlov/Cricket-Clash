export type ShotDirection = 'left' | 'straight' | 'right';

export type DeliveryType = 'fast' | 'cutter' | 'inswinger' | 'outswinger' | 'yorker';

export type TimingQuality = 'perfect' | 'good' | 'early' | 'late' | 'miss';

export type ShotOutcome = 'six' | 'four' | 'runs_3' | 'runs_2' | 'runs_1' | 'dot' | 'bowled' | 'caught' | 'lbw';

export interface BallDelivery {
  type: DeliveryType;
  name: string;
  speedKmh: number;
  color: string;
  targetX: number;
  bounceY: number;
  curveX: number;
  description: string;
}

export interface Fielder {
  id: number;
  name: string;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  speed: number;
  radius: number;
  isDiving: boolean;
  diveProgress: number;
  color: string;
  zone: 'midwicket' | 'longon' | 'cover' | 'point';
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  shape?: 'circle' | 'rect' | 'star';
  rotation?: number;
  vRot?: number;
}

export interface BallTrail {
  x: number;
  y: number;
  z: number;
  alpha: number;
  radius: number;
}

export interface FloatingText {
  id: number;
  text: string;
  subtext?: string;
  x: number;
  y: number;
  vy: number;
  scale: number;
  color: string;
  strokeColor?: string;
  alpha: number;
  life: number;
}

export interface BallHistoryEntry {
  ballNumber: number;
  outcome: ShotOutcome;
  runs: number;
  isWicket: boolean;
  commentary: string;
  speedKmh: number;
  shotType?: string;
}

export interface GameStats {
  totalRuns: number;
  targetRuns: number;
  ballsBowled: number;
  totalBalls: number;
  wicketsLost: number;
  maxWickets: number;
  foursCount: number;
  sixesCount: number;
  highestShotSpeed: number;
  history: BallHistoryEntry[];
}

export type GamePhase = 
  | 'idle' 
  | 'ready_to_bowl'
  | 'bowler_runup' 
  | 'ball_in_air_to_batsman' 
  | 'ball_struck' 
  | 'ball_dead' 
  | 'wicket_celebration' 
  | 'game_over' 
  | 'victory';

export type GameDifficulty = 'rookie' | 'pro' | 'legend';
